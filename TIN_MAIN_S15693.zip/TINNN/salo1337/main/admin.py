from django.contrib import admin
from .models import Meat, Client, Buy

# Register your models here.
admin.site.register(Meat)
admin.site.register(Client)
admin.site.register(Buy)