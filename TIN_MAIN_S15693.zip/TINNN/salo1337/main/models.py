from django.db import models

# Create your models here.


class Client(models.Model):
    name = models.CharField(max_length=15, default='')
    surname = models.CharField(max_length=15,  default='')
    email = models.EmailField(max_length=30, default='')
    telephone = models.CharField(max_length=10, default='')

    def __unicode__(self):
        return '{} {}'.format(self.name, self.surname)


class Meat(models.Model):
    name = models.CharField(max_length=50)
    weight = models.FloatField()


class Buy(models.Model):
    client = models.ForeignKey(Client, on_delete=Meat.delete)
    meat = models.ForeignKey(Meat, on_delete=Meat.delete)
    weight = models.FloatField(default=0.0)



