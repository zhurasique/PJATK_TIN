from django import forms
from .models import Meat, Client, Buy

class OrderForm(forms.Form):
    clientName=forms.CharField(
        widget=forms.TextInput(

        ),
        label='Name',
    )
    surname=forms.CharField(
        widget=forms.TextInput(

        ),
        label='Surname',
    )
    email = forms.EmailField(
        widget=forms.EmailInput(),
        label='Email'
    )
    telephone = forms.IntegerField(
        widget=forms.TextInput(
        ),
        label='Telephone'
    )

    # meat_select = forms.ChoiceField(
    #     #     choices=[(Meat.objects, x.name) for x in Meat.objects.all()]
    #     # )

    meat_select = forms.CharField(
        label='Type of meat'
    )

    weight = forms.FloatField(
        label='Weight'
    )

