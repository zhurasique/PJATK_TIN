from django.shortcuts import render, redirect
from django.http import HttpResponse
from .forms import OrderForm
from .models import Buy, Client, Meat
# Create your views here.


def login(request):
    return render(
        request,
        'main/login.html'
    )


def primary(request):
    orders = Buy.objects.all()
    return render(
        request,
        'main/primary.html',
        context={
            'orders': orders,
        }
    )


def buy(request):
    form = OrderForm()
    meat = Meat.objects.all()
    return render(
        request,
        'main/buy.html',
        context={
            'form': form,
            'meat': meat,
        }
    )

def place_order(request):
    if request.method == 'POST':
        print(request.POST)
        form = OrderForm(request.POST)
        if form.is_valid():
            if Client.objects.filter(name=form.cleaned_data['clientName'], surname=form.cleaned_data['surname'], email=form.cleaned_data['email'], telephone=form.cleaned_data['telephone']).exists():
                client = Client.objects.filter(name=form.cleaned_data['clientName'], surname=form.cleaned_data['surname'], email=form.cleaned_data['email'], telephone=form.cleaned_data['telephone'])[0]
                if Meat.objects.filter(name=form.cleaned_data['meat_select']).exists():
                    meat = Meat.objects.filter(name=form.cleaned_data['meat_select'])[0]
                    Buy.objects.create(client=client, meat=meat, weight=form.cleaned_data['weight'])
                else:
                    return HttpResponse('We dont have this type of meat')
                return redirect('/')
            else:
                client = Client.objects.create(name=form.cleaned_data['clientName'], surname=form.cleaned_data['surname'], email=form.cleaned_data['email'], telephone=form.cleaned_data['telephone'])
                if Meat.objects.filter(name=form.cleaned_data['meat_select']).exists():
                    meat = Meat.objects.filter(name=form.cleaned_data['meat_select'])[0]
                    Buy.objects.create(client=client, meat=meat, weight=form.cleaned_data['weight'])
                else:
                    return HttpResponse('We dont have this type of meat')
                return redirect('/')
        else:
            return HttpResponse('Data is no valid')



